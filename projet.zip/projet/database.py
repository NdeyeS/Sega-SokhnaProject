import os
import mariadb as database
from mariadb import Error

#Connexion à la base de données 
def ConnectDB():
    try:
        con = database.connect(host='localhost',database='mysql',user='root',password='passer')
        print("Base de données connectee")
        return con

    except database.Error as e:
        print(f"Erreur lors de la connexion : {e}")
        return False

#Creation d'un compte avec verification du mail
def Account(Liste: list):
    try:
        con = ConnectDB()
        cur = con.cursor()
        cur.executemany("INSERT INTO userA VALUES(?,?,?,?)",Liste)
        con.commit()
        if (Liste[2]in(cur.execute("SELECT mail FROM userA"))):
             print("Mail deja present")
        else:
            print("Donnees inserees avec succes")
    except database.Error as e:
        print(f"Erreur lors de l'insertion:{e}")


#Fonction qui permet qu'un utilisateur se connecte à son compte
def Login(Liste:list)-> list:
    try:
        con = ConnectDB()
        cur = con.cursor()
        cur.execute("SELECT * from userA where mail = '{Liste[2]}' AND password = '{Liste[3]}'")
    except database.Error as e:
        print("Indentifiants Invalides")